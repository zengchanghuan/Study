//
//  InteractiveAnimationViewController.h
//  facebook-pop-sample
//
//  Created by Luke on 5/21/14.
//  Copyright (c) 2014 geeklu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InteractiveAnimationViewController : UIViewController

@property (nonatomic, strong) UIView *testView;

@end
