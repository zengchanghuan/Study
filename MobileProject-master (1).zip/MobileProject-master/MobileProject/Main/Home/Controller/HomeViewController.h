//
//  HomeViewController.h
//  MobileProject 首页
//
//  Created by wujunyang on 16/1/14.
//  Copyright © 2016年 wujunyang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
