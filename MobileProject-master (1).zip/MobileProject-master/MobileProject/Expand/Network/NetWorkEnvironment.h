//
//  NetWorkEnvironment.h
//  MobileProject 枚举存放
//
//  Created by wujunyang on 16/1/5.
//  Copyright © 2016年 wujunyang. All rights reserved.
//

#ifndef NetWorkEnvironment_h
#define NetWorkEnvironment_h

typedef NS_ENUM(NSInteger,SERVERCENTER_TYPE)
{
    ACCOUNT_SERVERCENTER,
    PICTURE_SERVERCENTER,
    BUSINESSLOGIC_SERVERCENTER,
    UPDATEVERSION_SERVERCENTER
};

#endif /* NetWorkEnvironment_h */
