//
//  ThirdMacros.h
//  MobileProject 第三方SDK的Key及配置
//
//  Created by wujunyang on 16/1/5.
//  Copyright © 2016年 wujunyang. All rights reserved.
//

#ifndef ThirdMacros_h
#define ThirdMacros_h


//百度地图SDK的Key
#define  kBaiduMapKey @"20TTpXTnnp8TodtDXWjZBOvP"

//友盟统计SDK的key
#define kUmengKey @"53290df956240b6b4a0084b3"

//友盟分享
//--微信
#define kSocial_WX_ID @"wxdc1e388c3822c80b"
#define kSocial_WX_Secret @"a393c1527aaccb95f3a4c88d6d1455f6"
#define kSocial_WX_Url @"http://www.umeng.com/social"
//--QQ
#define kSocial_QQ_ID  @"100424468"
#define kSocial_QQ_Secret @"c7394704798a158208a74ab60104f0ba"
#define kSocial_QQ_Url @"http://www.umeng.com/social"
//--新浪微博
#define kSocial_Sina_Account @"3921700954"
#define kSocial_Sina_RedirectURL @"http://sns.whalecloud.com/sina2/callback"


//个推开发者网站中申请App时，注册的AppId、AppKey、AppSecret
#define kGtAppId           @"0uuwznWonIANoK07JeRWgA"
#define kGtAppKey          @"6LeO4stbrA7TeyMUJdXlx3"
#define kGtAppSecret       @"282vl0IwZd9KL3ZpDyoUL7"

#endif /* ThirdMacros_h */
