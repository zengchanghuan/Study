//
//  GVUserDefaults+BBProperties.m
//  GrowthDiary
//
//  Created by wujunyang on 16/1/5.
//  Copyright (c) 2016年 wujunyang. All rights reserved.
//

#import "GVUserDefaults+BBProperties.h"

@implementation GVUserDefaults (BBProperties)

@dynamic userName;
@dynamic name;
@dynamic role;
@end
