//
//  CoreAnimationViewController.h
//  popTest 普通动画效果
//
//  Created by wujunyang on 16/2/19.
//  Copyright © 2016年 wujunyang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CoreAnimationViewController : UIViewController

@end
