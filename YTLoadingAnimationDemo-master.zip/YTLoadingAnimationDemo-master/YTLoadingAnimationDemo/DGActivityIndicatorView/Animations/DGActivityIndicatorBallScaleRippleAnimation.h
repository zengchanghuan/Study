//
//  DGActivityIndicatorBallScaleTrippleAnimation.h
//  DGActivityIndicatorExample
//
//  Created by TonyAng on 16/4/1.
//  Copyright © 2016年 TonyAng. All rights reserved.
//

#import "DGActivityIndicatorAnimationProtocol.h"

@interface DGActivityIndicatorBallScaleRippleAnimation : NSObject <DGActivityIndicatorAnimationProtocol>

@end
